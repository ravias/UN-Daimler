# Databricks notebook source
finalDF=spark.read.table("nyctaxi.gold.finaltable")

# COMMAND ----------

finalDF.count()

# COMMAND ----------

finalDF.printSchema()

# COMMAND ----------

finalDF.show(5,False)

# COMMAND ----------

# Get a list of total trips in the month, maximum distance traveled by a trip in the month, maximum amount charged for a trip in the month, maximum time duration traveled in a trip in the month.

spark.sql('select count(*) as totaltrips, max(trip_distance) as maxdist, max(total_amount) as maxamt, max(trip_duration) maxdrn from nyctaxi.gold.finaltable').show()

# COMMAND ----------

# Get the details of the trip that has traveled the maximum distance in the month
# The details should contain pickup date & time, dropoff date & time, day of the week, pickup zone, dropoff zone, number of passengers, distance travelled, amount charged and time duration of the trip

spark.sql('select tpep_pickup_datetime, tpep_dropoff_datetime, day_of_week, pickupzone, dropoffzone, passenger_count, \
trip_distance, total_amount, trip_duration from nyctaxi.gold.finaltable where trip_distance=(select max(trip_distance) from nyctaxi.gold.finaltable)').show(truncate=False)

# COMMAND ----------

# Get the details of the trip that has charged the maximum amount in the month
# The details should contain pickup date & time, dropoff date & time, day of the week, pickup zone, dropoff zone, number of passengers, distance travelled, amount charged and time duration of the trip

spark.sql('select tpep_pickup_datetime, tpep_dropoff_datetime, day_of_week, pickupzone, dropoffzone, passenger_count, \
trip_distance, total_amount, trip_duration from nyctaxi.gold.finaltable where total_amount = (select max(total_amount) from nyctaxi.gold.finaltable)').show(truncate=False)


# COMMAND ----------

# Get the details of the trip that has travelled the maximum time duration in the month
# The details should contain pickup date & time, dropoff date & time, day of the week, pickup zone, dropoff zone, number of passengers, distance travelled, amount charged and time duration of the trip

spark.sql('select tpep_pickup_datetime, tpep_dropoff_datetime, day_of_week, pickupzone, dropoffzone, passenger_count, \
trip_distance, total_amount, trip_duration from nyctaxi.gold.finaltable where trip_duration = (select max(trip_duration) from nyctaxi.gold.finaltable)').show(truncate=False)

# COMMAND ----------

# Get the number of trips for which congestion surcharge is charged

spark.sql('select count(*) as surcharge_count from nyctaxi.gold.finaltable where (congestion_surcharge is not null) and (congestion_surcharge > 0)').show(truncate=False)

# COMMAND ----------

# Get the number of trips for which congestion surcharge is charged with a break up of the surcharge amount

spark.sql('select congestion_surcharge, count(*) as surcharge_count from nyctaxi.gold.finaltable where (congestion_surcharge is not null) and (congestion_surcharge > 0) group by congestion_surcharge order by congestion_surcharge').show(truncate=False)

# COMMAND ----------

# Get the percentage of trips for which congestion surcharge is charged out of the total trips of the month

spark.sql('select round(((select count(*) as surcharge_count from nyctaxi.gold.finaltable where (congestion_surcharge is not null) and (congestion_surcharge > 0))/count(*)*100),2) as congestionsurcharge_percent from nyctaxi.gold.finaltable').show(truncate=False)

# COMMAND ----------

# Write a query get a list of total trips, maximum distance traveled by a trip, maximum amount charged for a trip, maximum time duration traveled in a trip with a break up of the day of the week
# For each day of week it should list the total number of trips in that month, max distance traveled by a trip, max amount charged for a trip and max time duration trravelled in a trip

spark.sql("select day_of_week_num, day_of_week, count(*) as totaltrips, max(trip_distance) as maxdist, max(total_amount) as maxamt, max(trip_duration) as maxdrn from nyctaxi.gold.finaltable group by day_of_week_num, day_of_week order by day_of_week_num").show(truncate=False)

# COMMAND ----------

spark.sql("select day_of_week_num, max(trip_distance) as maxdist from nyctaxi.gold.finaltable group by day_of_week_num order by day_of_week_num").show(truncate=False)

# COMMAND ----------

# Get the details of the trip that has traveled the maximum distance with a break up of day of week in the month
# The details should contain pickup date & time, dropoff date & time, day of the week, pickup zone, dropoff zone, number of passengers, distance travelled, amount charged and time duration of the trip

spark.sql('select tpep_pickup_datetime, tpep_dropoff_datetime, day_of_week, pickupzone, dropoffzone, passenger_count, trip_distance, total_amount, trip_duration \
from nyctaxi.gold.finaltable a \
join (select day_of_week_num, max(trip_distance) as maxdist from nyctaxi.gold.finaltable group by day_of_week_num) q \
on a.day_of_week_num=q.day_of_week_num \
where a.trip_distance=q.maxdist order by a.day_of_week_num').show(truncate=False)

# COMMAND ----------

spark.sql("select day_of_week_num, max(total_amount) as maxamt from nyctaxi.gold.finaltable group by day_of_week_num order by day_of_week_num").show(truncate=False)

# COMMAND ----------

# Get the details of the trip that has charged the maximum amount with a break up of day of week in the month
# The details should contain pickup date & time, dropoff date & time, day of the week, pickup zone, dropoff zone, number of passengers, distance travelled, amount charged and time duration of the trip

spark.sql('select tpep_pickup_datetime, tpep_dropoff_datetime, day_of_week, pickupzone, dropoffzone, passenger_count, trip_distance, total_amount, trip_duration \
from nyctaxi.gold.finaltable a \
join (select day_of_week_num, max(total_amount) as maxamt from nyctaxi.gold.finaltable group by day_of_week_num) q \
on a.day_of_week_num=q.day_of_week_num \
where a.total_amount=q.maxamt order by a.day_of_week_num').show(truncate=False)

# COMMAND ----------

spark.sql("select day_of_week_num, max(trip_duration) as maxdrn from nyctaxi.gold.finaltable group by day_of_week_num order by day_of_week_num").show(truncate=False)

# COMMAND ----------

# Get the details of the trip that has traveled the maximum time duration with a break up of day of week in the month
# The details should contain pickup date & time, dropoff date & time, day of the week, pickup zone, dropoff zone, number of passengers, distance travelled, amount charged and time duration of the trip

spark.sql('select tpep_pickup_datetime, tpep_dropoff_datetime, day_of_week, pickupzone, dropoffzone, passenger_count, trip_distance, total_amount, trip_duration \
from nyctaxi.gold.finaltable a \
join (select day_of_week_num, max(trip_duration) as maxdrn from nyctaxi.gold.finaltable group by day_of_week_num) q \
on a.day_of_week_num=q.day_of_week_num \
where a.trip_duration=q.maxdrn order by a.day_of_week_num').show(truncate=False)

# COMMAND ----------

