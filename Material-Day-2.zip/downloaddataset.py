# Databricks notebook source
import urllib.request
import shutil
import os

# Target URL of the public file to download
url1 = "https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2026-09.parquet"

# Open a connection to the remote URL and fetch the Parquet file as a stream
response = urllib.request.urlopen(url1)

# Create the destination directory for storing the downloaded file
dir_path1 = "/Volumes/nyctaxi/bronze/rawdata/"
os.makedirs(dir_path1, exist_ok=True) 

# Define the full local path (including filename) where the file will be saved
local_path1 = f"{dir_path1}/yellow_tripdata_2026-09.parquet"

# Write the contents of the response stream to the specified local file path
with open(local_path1, 'wb') as f: 
    shutil.copyfileobj(response, f)

# Target URL of the public file to download
url2 = "https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2026-08.parquet"

# Open a connection to the remote URL and fetch the Parquet file as a stream
response = urllib.request.urlopen(url2)

# Create the destination directory for storing the downloaded file
dir_path2 = "/Volumes/nyctaxi/bronze/rawdata/"
os.makedirs(dir_path2, exist_ok=True) 

# Define the full local path (including filename) where the file will be saved
local_path2 = f"{dir_path2}/yellow_tripdata_2026-08.parquet"

# Write the contents of the response stream to the specified local file path
with open(local_path2, 'wb') as f: 
    shutil.copyfileobj(response, f)

# Target URL of the public csv file to download
url3 = "https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv"

# Open a connection to the remote URL and fetch the file as a stream
response = urllib.request.urlopen(url3)

# Create the destination directory for storing the downloaded file
dir_path3 = "/Volumes/nyctaxi/bronze/taxizones/"
os.makedirs(dir_path3, exist_ok=True) 

# Define the full local path (including filename) where the file will be saved
local_path3 = f"{dir_path3}/taxi_zone_lookup.csv"

# Write the contents of the response stream to the specified local file path
with open(local_path3, 'wb') as f: 
    shutil.copyfileobj(response, f)

