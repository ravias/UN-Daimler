# Databricks notebook source
taxitripDF0 = spark.read.load("/Volumes/nyctaxi/silver/cleandata")

# COMMAND ----------

taxitripDF0.show(5,False)

# COMMAND ----------

taxitripDF0.count()

# COMMAND ----------

taxitripDF0.printSchema()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

taxitripDF1=taxitripDF0.withColumn("day_of_week", date_format(col("tpep_pickup_datetime"), "EEEE"))\
.withColumn('day_of_week_num',dayofweek("tpep_pickup_datetime"))

# COMMAND ----------

taxitripDF1.show(5)

# COMMAND ----------

taxitripDF2=taxitripDF1.withColumn("pickup_hour", hour("tpep_pickup_datetime"))\
.withColumn("dropoff_hour", hour("tpep_dropoff_datetime"))

# COMMAND ----------

taxitripDF2.show(5)

# COMMAND ----------

taxitripDF2.printSchema()

# COMMAND ----------

taxitripDF3=taxitripDF2.withColumn("trip_duration", timestamp_diff("MINUTE",taxitripDF0.tpep_pickup_datetime,taxitripDF0.tpep_dropoff_datetime))

# COMMAND ----------

taxitripDF3.show(5)

# COMMAND ----------

taxitripDF3.printSchema()

# COMMAND ----------

zoneDF0 = spark.read.load("/Volumes/nyctaxi/bronze/taxizones/taxi_zone_lookup.csv", format="csv", inferSchema="true", header="true")

# COMMAND ----------

zoneDF0.show(5)

# COMMAND ----------

zoneDF0.count()

# COMMAND ----------

zoneDF0.printSchema()

# COMMAND ----------

zoneDF1=zoneDF0.select('LocationId', 'Zone')

# COMMAND ----------

zoneDF1.printSchema()

# COMMAND ----------

zoneDF1.show(5)

# COMMAND ----------

taxitripDF4=taxitripDF3.join(zoneDF1,taxitripDF3.PULocationID==zoneDF1.LocationId)

# COMMAND ----------

taxitripDF4.show(5)

# COMMAND ----------

taxitripDF4.printSchema()

# COMMAND ----------

taxitripDF5=taxitripDF4.drop("LocationId").withColumnRenamed('Zone','PickUPZOne')

# COMMAND ----------

taxitripDF5.show(5)

# COMMAND ----------

taxitripDF5.printSchema()

# COMMAND ----------

taxitripDF6=taxitripDF5.join(zoneDF1,taxitripDF5.DOLocationID==zoneDF1.LocationId).drop('LocationId')\
.withColumnRenamed('Zone','DropOffZone')

# COMMAND ----------

taxitripDF6.count()

# COMMAND ----------

taxitripDF7.write.mode("overwrite").saveAsTable('nyctaxi.gold.finaltable')