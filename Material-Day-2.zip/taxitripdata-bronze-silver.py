# Databricks notebook source
taxitripDF0 = spark.read.load("/Volumes/nyctaxi/bronze/rawdata/", format="parquet")

# COMMAND ----------

taxitripDF0.show(5,False)

# COMMAND ----------

taxitripDF0.count()

# COMMAND ----------

taxitripDF0.printSchema()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

taxitripDF0.filter(taxitripDF0.trip_distance>0).count()

# COMMAND ----------

taxitripDF0.filter(taxitripDF0.trip_distance>0).filter(taxitripDF0.fare_amount>0).count()

# COMMAND ----------

taxitripDF0.filter(taxitripDF0.trip_distance>0).filter(taxitripDF0.fare_amount>0).filter(taxitripDF0.total_amount>0).filter(timestamp_diff("MINUTE",taxitripDF0.tpep_pickup_datetime,taxitripDF0.tpep_dropoff_datetime)>0).count()

# COMMAND ----------

taxitripDF1=taxitripDF0.filter(taxitripDF0.trip_distance>0).filter(taxitripDF0.fare_amount>0).filter(taxitripDF0.total_amount>0).filter(timestamp_diff("MINUTE",taxitripDF0.tpep_pickup_datetime,taxitripDF0.tpep_dropoff_datetime)>0)

# COMMAND ----------

spark.sql("create volume if not exists nyctaxi.silver.cleandata")

# COMMAND ----------

taxitripDF1.write.mode("overwrite").save("/Volumes/nyctaxi/silver/cleandata")