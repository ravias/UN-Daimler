# Databricks notebook source
# Target Delta Table instance
from delta.tables import DeltaTable

dt = DeltaTable.forName(spark, "ws_ravi1_7405614243474633.countriesschema.regions")

# COMMAND ----------

# You can convert a DeltaTable instance to a DataFrame with toDF()
# This enables you to display the contents
# This is an alternative to the DataFrameReader API (spark.read.format("delta").load(...))

dt.toDF().display()

# COMMAND ----------

# Deleting the record with id = 100 before proceeding

dt.delete("id = 100")

# COMMAND ----------

# The source DataFrame

df = spark.read.\
        format("csv").\
        option("header", True).\
        schema("id int, name string").\
        load("/Volumes/ws_ravi1_7405614243474633/countriesschema/dataset/country_regions.csv")

df.display()

# COMMAND ----------

# Begin a merge operation on the target Delta table (aliased as "target")
dt.alias("target").\
    merge(
        df.alias("source"), # Merge with the source DataFrame (aliased as "source") based on matching 'id'
        "target.id = source.id"
    ).\
    whenMatchedUpdate(
        set = {
            "target.name": "source.name" # If a match is found on 'id', update the 'name' column in the target with the source value
        }
    ).\
    whenNotMatchedInsert( # If no match is found, insert a new row into the target with values from the source
        values = {
            "target.id": "source.id", 
            "target.name": "source.name"
        }
    ).execute()  # Execute the merge operation

# COMMAND ----------

dt.toDF().display()