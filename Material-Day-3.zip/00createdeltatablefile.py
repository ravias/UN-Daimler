# Databricks notebook source
populationDF = spark.read.csv("/Volumes/ws_ravi1_7405614243474633/countriesschema/dataset/countries_population.csv", header=True, inferSchema=True)
display(populationDF)


# COMMAND ----------

populationDF.write.format("delta").mode("overwrite").save("/Volumes/ws_ravi1_7405614243474633/countriesschema/population/")

# COMMAND ----------

regionDF = spark.read.csv("/Volumes/ws_ravi1_7405614243474633/countriesschema/dataset/country_regions.csv", header=True, inferSchema=True)
display(regionDF)


# COMMAND ----------

regionDF.write.format('delta').mode("overwrite").saveAsTable('ws_ravi1_7405614243474633.countriesschema.regions')

# COMMAND ----------

