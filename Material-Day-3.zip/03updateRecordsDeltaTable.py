# Databricks notebook source
# Previewing the country_regions table

spark.read.table("ws_ravi1_7405614243474633.countriesschema.regions").display()

# COMMAND ----------

# Updating the records where name = 'Asia'
# When the condition is true the id column should contain the value 100 and the name column values should be in uppercase

from delta.tables import DeltaTable
from pyspark.sql.functions import lit, upper

dt = DeltaTable.forName(spark, "ws_ravi1_7405614243474633.countriesschema.regions")

dt.update(
    condition = "name = 'Asia'",
    set = {
        "id": lit(100),
        "name": upper("name")
    }
)

# COMMAND ----------

# Updating all conditions by specifying the condition = None
# Updating the name column values to be in uppercase

dt.update(
    condition = None,
    set = {
        "name": upper("name")
    }
)