# Databricks notebook source
# Importing the DeltaTable API
from delta.tables import DeltaTable

# COMMAND ----------

# Creating a DeltaTable instance using forName to reference a Unity Catalog Delta Table

dt1 = DeltaTable.forName(spark, "ws_ravi1_7405614243474633.countriesschema.regions")

# COMMAND ----------

type(dt1)

# COMMAND ----------

# Creating a DeltaTable instance using forName to reference a Unity Catalog Delta File Path

dt2 = DeltaTable.forPath(spark, "/Volumes/ws_ravi1_7405614243474633/countriesschema/population/")

# COMMAND ----------

type(dt2)