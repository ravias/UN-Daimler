# Databricks notebook source
# Work with Delta Lake table history](https://learn.microsoft.com/en-us/azure/databricks/delta/history)
# Restore a Delta table to an earlier state](https://learn.microsoft.com/en-us/azure/databricks/delta/history#restore)

# COMMAND ----------

spark.sql("""
          DESCRIBE HISTORY delta.`/Volumes/ws_ravi1_7405614243474633/countriesschema/studentdata/`
          """).display()

# COMMAND ----------

# Using versionAsOf option

spark.read.format("delta").option("versionAsOf", "16").load("/Volumes/ws_ravi1_7405614243474633/countriesschema/studentdata/").display()

# COMMAND ----------

# Using timestampAsOf option

spark.read.format("delta").option("timeStampAsOf", "2026-11-24T21:47:51.000+00:00").load("/Volumes/ws_ravi1_7405614243474633/countriesschema/studentdata/").display()

# COMMAND ----------

# Restore a Delta table to an earlier state

spark.sql("""
          RESTORE delta.`/Volumes/ws_ravi1_7405614243474633/countriesschema/studentdata/` TO VERSION AS OF 0
          """)

# COMMAND ----------

# Restore will be added to history

spark.sql("""
          DESCRIBE HISTORY delta.`/Volumes/ws_ravi1_7405614243474633/countriesschema/studentdata/`
          """).display()