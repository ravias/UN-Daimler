# Databricks notebook source
# Previewing the country_regions table
spark.read.table("ws_ravi1_7405614243474633.countriesschema.regions").display()

# COMMAND ----------

# Creating a Delta Table instance 
from delta.tables import DeltaTable

# COMMAND ----------

dt = DeltaTable.forName(spark, "ws_ravi1_7405614243474633.countriesschema.regions")

# COMMAND ----------

# Deleting Records from the Delta Table where name = 'America'
dt.delete("name = 'America'")

# COMMAND ----------

# Confirming the record has been deleted

df = spark.read.table("ws_ravi1_7405614243474633.countriesschema.regions")
df.display()

# COMMAND ----------

#### The equivalent operation is not possible using the DataFrameWriter API
# To delete even a single record you need to overwrite the entire dataset.
# This full table rewrite can get expensive if you have a table with billions of rows.

# COMMAND ----------

# For example

df = spark.read.table("ws_ravi1_7405614243474633.countriesschema.regions")

df = df.filter("name != 'Europe'")

# Use mode as overwrite to update the data, this is inefficient as it results in a full table rewrite
df.write.mode("overwrite").saveAsTable("ws_ravi1_7405614243474633.countriesschema.regions")