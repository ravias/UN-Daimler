# Databricks notebook source
# Create DataFrame from data source - csv file
customerDF = spark.read.load("customers.txt", format="csv", sep="\t", inferSchema="true", header="true")

# COMMAND ----------

# df.cache() perisits the dataframe partitions in the respective nodes
# This makes future actions faster
customerDF.cache()

# COMMAND ----------

# df.persist takes the storage level as argument and persists the dataframe accordingly
# Default storage level is MEMORY_AND_DISK_DESER
# https://spark.apache.org/docs/3.5.9/api/python/reference/pyspark.sql/api/pyspark.sql.DataFrame.persist.html#pyspark.sql.DataFrame.persist
# For example

# from pyspark.storagelevel import StorageLevel
# customerDF.persist(StorageLevel.DISK_ONLY)

# COMMAND ----------

customerDF.show(5)

# COMMAND ----------

# Now rename or delete the file customers.txt

# COMMAND ----------

groupDF=customerDF.groupBy("customer_state").count()

# COMMAND ----------

groupDF.show()

# COMMAND ----------

# We did NOT get an error this time as the dataframe is perisisted/cached

# COMMAND ----------

# The next 2 lines should run without any error

# COMMAND ----------

groupAndOrderDF=customerDF.groupBy("customer_state").count().orderBy("customer_state")

# COMMAND ----------

groupAndOrderDF.show()