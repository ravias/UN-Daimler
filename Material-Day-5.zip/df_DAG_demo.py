# Databricks notebook source
# Create DataFrame from data source - csv file
customerDF = spark.read.load("/Volumes/dbws_ravi1_7405605319611548/pysparksql_files/retaildata/customers.txt", format="csv", sep="\t", inferSchema="true", header="true")

# COMMAND ----------

from pyspark.sql.functions import split

# COMMAND ----------

customerDF1 = customerDF.withColumn("full_name", split(customerDF["customer_name"], " "))

# COMMAND ----------

customerDF2 = customerDF1.withColumn("first_name", customerDF1["full_name"].getItem(0)) \
                   .withColumn("last_name", customerDF1["full_name"].getItem(1)) \
                   .drop("full_name") # Drop the temporary array column

# COMMAND ----------

customerDF3=customerDF2.select("customer_id","first_name","last_name","customer_city","customer_state")

# COMMAND ----------

customerDF4=customerDF3.groupBy("customer_state").count()

# COMMAND ----------

customerDF4.show()

# COMMAND ----------

customerDF5=customerDF4.filter(customerDF4["count"]>10)

# COMMAND ----------

customerDF5.show(5)