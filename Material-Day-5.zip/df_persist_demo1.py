# Databricks notebook source
# Create DataFrame from data source - csv file
customerDF = spark.read.load("/Volumes/dbws_ravi1_7405605319611548/pysparksql_files/retaildata/customers.txt", format="csv", sep="\t", inferSchema="true", header="true")

# COMMAND ----------

customerDF.show(5)

# COMMAND ----------

# Now rename or delete the file customers.txt

# COMMAND ----------

groupDF=customerDF.groupBy("customer_state").count()

# COMMAND ----------

groupDF.show()

# COMMAND ----------

# We get an error because Spark tries to build the dataframe from scratch i.e from the step of reading the file

# COMMAND ----------

# Directly run the line to stop spark session object.
# No need to run the next 2 lines

# COMMAND ----------

groupAndOrderDF=customerDF.groupBy("customer_state").count().orderBy("customer_state")

# COMMAND ----------

groupAndOrderDF.show()