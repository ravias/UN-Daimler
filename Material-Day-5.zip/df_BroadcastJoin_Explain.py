# Databricks notebook source
# MAGIC %md
# MAGIC #### Dataframe Joins and Optimizations
# MAGIC SparkSQL builds in several optimizations while performing joins and other operations on dataframes.
# MAGIC
# MAGIC We can check out the execution plan of SparkSQL for any operation using the function "explain()"
# MAGIC
# MAGIC When one of the dataframes in the join operation is small enough to fit into a workernode then Spark SQL plans to "broadcast" this dataframe. This is generally referred to as BroadcastJoin. When a dataframe is "broadcasted" then a copy of it is sent to all worker nodes. This avoids shuffling of data when joining it with the larger dataframe as the smaller dataframe is compltely available locally for each partition of the larger dataframe.
# MAGIC
# MAGIC The above optimization is done automatically by SparkSQL's built-in optimizer. However we can also check to ensure it is done and in case it is not done it can be done manually also as shown in the example below.
# MAGIC
# MAGIC The setting "spark.sql.autoBroadcastJoinThreshold" determines whether a dataframe is small enough to be broadcast or not. The default of this setting is 10 MB (10485760). We can override this when we know that the smaller dataframe is just above this threshold and can be managed to be fit into each worker node. 

# COMMAND ----------

# MAGIC %md
# MAGIC Create DataFrame from data source - csv file

# COMMAND ----------

customerDF = spark.read.load("/Volumes/ws_ravi3_7405612811282632/retaildata/customers/customers.tsv", format="csv", sep="\t", inferSchema="true")
salestxnDF = spark.read.load("/Volumes/ws_ravi3_7405612811282632/retaildata/productsales/salestxns.tsv", format="csv", sep="\t", inferSchema="true")

# COMMAND ----------

customerDF.printSchema()

# COMMAND ----------

salestxnDF.printSchema()

# COMMAND ----------

new_names_cDF = ['customer_id','customer_name','customer_city','customer_state','customer_zipcode']

# COMMAND ----------

new_names_sDF = ['salestxn_id','category_id','category_name','product_id','product_name','product_price','product_quantity','\
customer_id']

# COMMAND ----------

cDF2=customerDF.toDF(*new_names_cDF)

# COMMAND ----------

sDF2=salestxnDF.toDF(*new_names_sDF)

# COMMAND ----------

cDF2.printSchema()

# COMMAND ----------

cDF2.show(5)

# COMMAND ----------

cDF2.count()

# COMMAND ----------

cDF2.rdd.getNumPartitions()

# COMMAND ----------

sDF2.printSchema()

# COMMAND ----------

sDF2.show(5)

# COMMAND ----------

sDF2.count()

# COMMAND ----------

sDF2.rdd.getNumPartitions()

# COMMAND ----------

# MAGIC %md
# MAGIC Join the two dataframes on customer_id column

# COMMAND ----------

jDF1=cDF2.join(sDF2,cDF2.customer_id==sDF2.customer_id)

# COMMAND ----------

jDF1.printSchema()

# COMMAND ----------

jDF1.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC Use explain() function to see the type of join used by Spark SQL

# COMMAND ----------

jDF1.explain()

# COMMAND ----------

# MAGIC %md
# MAGIC Using explain(True) function gives the outline of the initial logical plans besides the final physical plan used for executing the join operation

# COMMAND ----------

jDF1.explain(True)

# COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

# COMMAND ----------

# MAGIC %md
# MAGIC By setting this value to -1 broadcasting can be disabled.

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

spark.conf.get("spark.sql.autoBroadcastJoinThreshold")

# COMMAND ----------

jDF2=cDF2.join(sDF2,cDF2.customer_id==sDF2.customer_id)

# COMMAND ----------

# Since autoBroadcastJoinThreshold is disabled by setting it to -1, physical plan shows BroadCastJoin it is not used.
jDF2.explain()

# COMMAND ----------

# MAGIC %md
# MAGIC We can notice that broadcast join is not used now as the threshold is disabled.

# COMMAND ----------

jDF2.printSchema()

# COMMAND ----------

jDF2.show(5)

# COMMAND ----------

# MAGIC %md
# MAGIC The lines below show how to mark a dataframe for broadcast in case required to be done manually.

# COMMAND ----------

jDF3=cDF2.hint("broadcast").join(sDF2,cDF2.customer_id==sDF2.customer_id)

# COMMAND ----------

jDF3.explain()

# COMMAND ----------

jDF3.printSchema()

# COMMAND ----------

jDF3.show(5)

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

jDF4=F.broadcast(cDF2).join(sDF2,cDF2.customer_id==sDF2.customer_id)

# COMMAND ----------

jDF4.explain()

# COMMAND ----------

jDF4.printSchema()

# COMMAND ----------

jDF4.show(5)

# COMMAND ----------

cDF2.cache()
# cDF2.count()

# COMMAND ----------

sDF2.persist()
# sDF2.count()

# COMMAND ----------

jDF5=F.broadcast(cDF2).join(sDF2,cDF2.customer_id==sDF2.customer_id)

# COMMAND ----------

jDF5.explain()

# In the physical plan below we can see "InMemoryTableScan" being used for both the dataframes
# which was not the case in the previous one.
# This means that the data is persisted and reused from cache insted of re-building the dataframes from scratch.

# COMMAND ----------

# In the statement below, after join we are doing a filter and also we are doing select of only 5 columns.

jDF6=cDF2.hint("broadcast").join(sDF2,cDF2.customer_id==sDF2.customer_id).\
select('customer_name','customer_city', 'customer_state', 'product_name','product_price','product_quantity').where(cDF2.customer_state=='IL')

# In the physical plan shown after the explain statement, we can see projection (select clause) push and filter push.
# This means that the query execution engine executes projection and then filter and only after that join is executed,
# which is more optimal way of executing the whole statement.

# COMMAND ----------

jDF6.show()

# COMMAND ----------

jDF6.explain()

# COMMAND ----------

jDF6.count()