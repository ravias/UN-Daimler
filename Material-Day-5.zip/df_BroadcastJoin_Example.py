# Databricks notebook source
# MAGIC %md
# MAGIC #### Dataframe Joins and Optimizations
# MAGIC SparkSQL builds in several optimizations while performing joins and other operations on dataframes.
# MAGIC
# MAGIC We can check out the execution plan of SparkSQL for any operation using the function "explain()"
# MAGIC
# MAGIC When one of the dataframes in the join operation is small enough to fit into a workernode then Spark SQL plans to "broadcast" this dataframe. This is generally referred to as BroadcastJoin. When a dataframe is "broadcasted" then a copy of it is sent to all worker nodes. This avoids shuffling of data when joining it with the larger dataframe as the smaller dataframe is compltely available locally for each partition of the larger dataframe.
# MAGIC
# MAGIC The above optimization is done automatically by SparkSQL's built-in optimizer. However we can also check to ensure it is done and in case it is not done it can be done manually also as shown in the example below.
# MAGIC
# MAGIC The setting "spark.sql.autoBroadcastJoinThreshold" determines whether a dataframe is small enough to be broadcast or not. The default of this setting is 10 MB (10485760). We can override this when we know that the smaller dataframe is just above this threshold and can be managed to be fit into each worker node.
# MAGIC
# MAGIC This notebook gives an example of good practices like use of cache() or persist()

# COMMAND ----------

# MAGIC %md
# MAGIC Create DataFrame from data source - csv file

# COMMAND ----------

customerDF = spark.read.load("/Volumes/ws_ravi3_7405612811282632/retaildata/customers/customers.tsv", format="csv", sep="\t", inferSchema="true")
salestxnDF = spark.read.load("/Volumes/ws_ravi3_7405612811282632/retaildata/productsales/salestxns.tsv", format="csv", sep="\t", inferSchema="true")

# COMMAND ----------

customerDF.printSchema()

# COMMAND ----------

salestxnDF.printSchema()

# COMMAND ----------

new_names_cDF = ['customer_id','customer_name','customer_city','customer_state','customer_zipcode']

# COMMAND ----------

new_names_sDF = ['salestxn_id','category_id','category_name','product_id','product_name','product_price','product_quantity',\
                 'customer_id']

# COMMAND ----------

cDF2=customerDF.toDF(*new_names_cDF)

# COMMAND ----------

cDF2.cache()

# COMMAND ----------

sDF2=salestxnDF.toDF(*new_names_sDF)

# COMMAND ----------

sDF2.persist()

# COMMAND ----------

# MAGIC %md
# MAGIC Join the two dataframes on customer_id column

# COMMAND ----------

# In the statement below, after join we are doing a filter and also we are doing select of only 5 columns.

jDF1=cDF2.hint("broadcast").join(sDF2,cDF2.customer_id==sDF2.customer_id).\
select('customer_name','customer_city', 'customer_state', 'product_name','product_price','product_quantity').\
where(cDF2.customer_state=='IL')

# In the physical plan shown after the explain statement, we can see projection (select clause) push and filter push.
# This means that the query execution engine executes projection and then filter and only after that join is executed,
# which is more optimal way of executing the whole statement.

# COMMAND ----------

jDF1.show()

# COMMAND ----------

jDF1.count()