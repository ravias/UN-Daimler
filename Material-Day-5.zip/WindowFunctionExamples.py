# Databricks notebook source
# Create DataFrame from data source - csv file
orderDetails = spark.read.load("/Volumes/ws_ravi3_7405612811282632/retaildata/ordersdata/orderdetails.csv", format="csv", inferSchema="true", header="true")

# COMMAND ----------

orderDetails.count()

# COMMAND ----------

orderDetails.printSchema()

# COMMAND ----------

orderDetails.show(5)

# COMMAND ----------

# examples
from pyspark.sql.window import Window
from pyspark.sql.functions import *

# COMMAND ----------

windowSpec1  = Window.orderBy(col("quantityOrdered").desc())

# COMMAND ----------

# MAGIC %md
# MAGIC RANK(): Calculates the rank of a value in a group of values.
# MAGIC The result set records are ordered by quantityordered in descending order.
# MAGIC Rank() gives each record a rank starting with 1 for the first one.
# MAGIC It gives the same rank for the records with the same values. It adds the number of tied records to the tied rank to calculate the next rank. Therefore, the ranks may not be consecutive numbers.
# MAGIC For example if there are two records have the same rank 4, then these two will get the rank 4. The following record will get the rank 6 (Rank # 5 will be skipped.)
# MAGIC
# MAGIC SELECT ordernumber, productcode, quantityordered,
# MAGIC RANK() OVER (ORDER BY quantityordered DESC) as myrank1
# MAGIC FROM orderdetailsvu limit 30;

# COMMAND ----------

orderDetails.createOrReplaceTempView("orderdetailsvu")

# COMMAND ----------

spark.sql("SELECT ordernumber, productcode, quantityordered, RANK() OVER (ORDER BY quantityordered DESC) as myrank1 FROM orderdetailsvu limit 30;").\
    show(40)

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("rank",rank().over(windowSpec1)).show(40)

# COMMAND ----------

# MAGIC %md
# MAGIC The above considers all the records in the table.
# MAGIC If we want to get the ranking of records within each productcode we can use partition by clause as shown below.
# MAGIC The rank query below ranks the records within each productcode.
# MAGIC
# MAGIC SELECT ordernumber, productcode, quantityordered,
# MAGIC RANK() OVER (PARTITION BY productcode ORDER BY quantityordered DESC) as myrank2
# MAGIC FROM orderdetailsvu ORDER BY productcode limit 40;

# COMMAND ----------

spark.sql("SELECT ordernumber, productcode, quantityordered, \
RANK() OVER (PARTITION BY productcode ORDER BY quantityordered DESC) as myrank2 \
FROM orderdetailsvu ORDER BY productcode limit 40;").show(40)

# COMMAND ----------

windowSpec2  = Window.partitionBy("productCode").orderBy(col("quantityOrdered").desc())

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("rank",rank().over(windowSpec2)).show(40)

# COMMAND ----------

# MAGIC %md
# MAGIC DENSE_RANK(): Acts like the RANK function except that it assigns consecutive ranks
# MAGIC The result set records are ordered by quantityOrdered in descending order.
# MAGIC Dense_Rank() also gives each record a rank starting with 1 for the first one.
# MAGIC It gives the same rank for the records with the same values. But it does NOT add the number of tied records to the tied rank to calculate the next rank. Therefore, the ranks are in consecutive numbers.
# MAGIC
# MAGIC SELECT ordernumber, productcode, quantityordered,
# MAGIC DENSE_RANK() OVER (ORDER BY quantityordered DESC) as mydenserank1
# MAGIC FROM orderdetailsvu limit 30;

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("dense_rank",dense_rank().over(windowSpec1)).show(40)

# COMMAND ----------

# MAGIC %md
# MAGIC The above considers all the records in the table.
# MAGIC If we want to get the dense_ranking of records within each productcode we can use partition by clause as shown below.
# MAGIC The above query gives dense_ranks to the records within each productcode.
# MAGIC
# MAGIC SELECT ordernumber, productcode, quantityordered,
# MAGIC DENSE_RANK() OVER (PARTITION BY productcode ORDER BY quantityordered DESC) as mydenserank2
# MAGIC FROM orderdetailsvu ORDER BY productcode limit 40;

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("dense_rank",dense_rank().over(windowSpec2)).show(40)

# COMMAND ----------

# MAGIC %md
# MAGIC ROW_NUMBER(): Gives a running serial number to a partition of records
# MAGIC The following query lists the records in descending order of quantityordered starting with the maximum quantityordered.
# MAGIC
# MAGIC SELECT ordernumber, productcode, priceeach, quantityordered,
# MAGIC ROW_NUMBER() OVER (ORDER BY quantityordered DESC) as myrownumber1
# MAGIC FROM orderdetails limit 40;

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("row_number",row_number().over(windowSpec1)).show(40)

# COMMAND ----------

# MAGIC %md
# MAGIC In Row_Number() function also we can use partition by clause if we want the numbering to be done within each productcode.
# MAGIC
# MAGIC SELECT ordernumber, productcode, quantityordered,
# MAGIC ROW_NUMBER() OVER (PARTITION BY productcode ORDER BY quantityordered DESC) as myrownumber2
# MAGIC FROM orderdetailsvu ORDER BY productcode limit 40;

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("row_number",row_number().over(windowSpec2)).show(40)

# COMMAND ----------

# MAGIC %md
# MAGIC We can provide one more order by criteria which can resolve the ties where two or more records have the same quantityordered.
# MAGIC In the above query we are using priceeach also as one more order by criteria for ordering the records. So when there are two or more records with same quantityordered then they will be sorted based on priceeach starting with lesser priceeach.
# MAGIC
# MAGIC SELECT ordernumber, productcode, priceeach, quantityordered,
# MAGIC ROW_NUMBER() OVER (ORDER BY quantityordered, priceeach) as myrownumber3
# MAGIC FROM orderdetails limit 40;

# COMMAND ----------

windowSpec3  = Window.orderBy(col("quantityOrdered").desc(),col("priceEach").desc())

# COMMAND ----------

orderDetails.select("orderNumber","productCode","priceEach","quantityOrdered").withColumn("row_number",row_number().over(windowSpec3)).show(150)

# COMMAND ----------

# MAGIC %md
# MAGIC We can use DENSE_RANK to answer queries like:
# MAGIC  - Get the ordernumber and productcode with the second highest second-highest quantityordered
# MAGIC We just need to:
# MAGIC  - Do a DENSE_RANK over quantityordered in descending order and
# MAGIC  - Then take the record(s) with DENSE_RANK 2.
# MAGIC
# MAGIC SELECT * FROM
# MAGIC    (SELECT ordernumber, productcode, quantityordered,
# MAGIC     DENSE_RANK() OVER (ORDER BY quantityordered DESC) AS myrank
# MAGIC     FROM orderdetails) q
# MAGIC WHERE myrank=2;

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("dense_rank",dense_rank().over(windowSpec1)).\
    filter(col("dense_rank")==2).show()

# COMMAND ----------

# MAGIC %md
# MAGIC We can similarly get any other dense rank as well, for example 4th highest quantityordered.
# MAGIC
# MAGIC SELECT * FROM
# MAGIC    (SELECT ordernumber, productcode, quantityordered,
# MAGIC     DENSE_RANK() OVER (ORDER BY quantityordered DESC) AS myrank
# MAGIC     FROM orderdetails) q
# MAGIC WHERE myrank=4;

# COMMAND ----------

orderDetails.select("orderNumber","productCode","quantityOrdered").withColumn("dense_rank",dense_rank().over(windowSpec1)).\
    filter(col("dense_rank")==4).show()